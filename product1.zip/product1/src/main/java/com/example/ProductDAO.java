package com.example;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

public class ProductDAO {
	private HibernateTemplate temp;

	public void setTemp(HibernateTemplate temp) {
		this.temp = temp;
	}
	
	//insert
	public int insert(Product p) {
		return (int) temp.save(p);
	}
	
	//update and delete -> temp.update , temp.delete 
	
//retrieve 
	public List<Product> getal(){
		return (List<Product>) temp.find("from Product");
	}
	
	
}


